package skijanje;

public enum TipSkijanja {
    REKREATIVNO,
    TRENING,
    TAKMICARSKO
}
